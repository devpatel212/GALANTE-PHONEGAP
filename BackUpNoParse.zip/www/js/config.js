/* URL for the WordPress JSON API */
var API_BASE_URL = "http://staging.galante.london/api";

/* ID numbers for the PushWoosh messaging system */
var PUSHWOOSH_ID = "XXXXX-YYYYY";
var GCM_PROJECT_NUMBER = "00000000000";
